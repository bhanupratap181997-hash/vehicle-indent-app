VEHICLE INDENT MANAGER — SETUP GUIDE

This is a small installable web app prototype with Firebase Email/Password login, user-owned Firestore records, status changes/history, and monthly location dashboard. It does not include any pre-filled Firebase credentials; add your own web app config before use.

A. GET YOUR WEB APP CONFIG
1. Open https://console.firebase.google.com/ and select your Vehicle Indent Management project.
2. Project Overview > gear icon > Project settings > General.
3. Under Your apps, select the Web app you registered. If you do not have a Web app, add one (</>).
4. Find SDK setup and configuration > Config. Copy the values for apiKey, authDomain, projectId, storageBucket, messagingSenderId, appId.
5. Open index.html in a text editor and replace the firebaseConfig values near the bottom. Replace PASTE_API_KEY, PASTE_PROJECT_ID, PASTE_SENDER_ID, PASTE_APP_ID with your own exact values. Do not share private passwords. Firebase web config is not a password, but keep your database rules secure.

B. FIREBASE AUTH
Authentication > Sign-in method > Email/Password > Enable > Save. Create/sign in using the app's own email/password account. This password is the Firebase app account password, not necessarily your Google password.

C. FIRESTORE RULES — IMPORTANT
Before storing real data, open Firestore Database > Rules and replace the temporary Test Mode rules with the content of firestore.rules in this package, then Publish. These rules restrict each account to records with its own ownerUid. Do not leave Test Mode rules active. This app's account records are private to that account; another account will not see them.

D. HOST THE APP (Firebase Hosting)
1. Install Node.js on a computer and Firebase CLI: npm install -g firebase-tools
2. In this folder, create a file named firebase.json containing:
   {"hosting":{"public":".","ignore":["firebase.json","**/.*","**/node_modules/**"]}}
3. In terminal in this folder run: firebase login
4. Run: firebase init hosting (choose existing project; public directory '.', configure as single-page app: No, do not overwrite index.html)
   Alternatively create firebase.json above, then run: firebase deploy --only hosting
5. Open the Hosting URL on your phone and use browser menu > Add to Home screen / Install app.

E. FEATURES
- Create and edit indents; required date has date only (no time input).
- Statuses: Pending, Placed, Received, Cancelled.
- Status changes are recorded in history with timestamp.
- Monthly dashboard: total indents by indent month, placements by the month the vehicle was marked Placed, current Received/Cancelled status counts for indents created that month, and location-wise placements.
- Records are cloud-synced and available on another phone after signing in with the same app account.

NOTES
- The dashboard placement count is based on placedAt date. If an indent is marked Placed, later changed to Received or Cancelled, it remains counted as placed in that month.
- Keep your account credentials private. Firebase usage is subject to current free-tier quotas.
- This package is a starter implementation; it has not been connected to your Firebase project or deployed automatically.
